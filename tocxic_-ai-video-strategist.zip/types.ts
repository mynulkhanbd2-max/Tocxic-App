
export interface ViralStrategy {
  titles: {
    clickbait: string;
    curiosity: string;
    story: string;
  };
  hook: string;
  script: {
    intro: string;
    body1: string;
    body2: string;
    body3: string;
    conclusion: string;
  };
  cta: string;
  thumbnail: {
    visualDescription: string;
    textOverlay: string;
  };
  seo: {
    metaDescription: string;
    tags: string[];
    hashtags: string[];
  };
}

export enum Language {
  Bengali = 'Bengali',
  English = 'English'
}

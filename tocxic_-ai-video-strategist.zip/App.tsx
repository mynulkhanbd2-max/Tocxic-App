
import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Loader } from './components/Loader';
import { StrategyDisplay } from './components/StrategyDisplay';
import { generateViralStrategy } from './services/geminiService';
import { ViralStrategy, Language } from './types';

const App: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [language, setLanguage] = useState<Language>(Language.Bengali);
  const [loading, setLoading] = useState(false);
  const [strategy, setStrategy] = useState<ViralStrategy | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setLoading(true);
    setError(null);
    setStrategy(null);

    try {
      const result = await generateViralStrategy(topic, language);
      setStrategy(result);
    } catch (err) {
      setError('Failed to generate strategy. Please check your API key and try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="bg-slate-900/50 p-6 md:p-8 rounded-3xl border border-slate-800 backdrop-blur-md shadow-2xl mb-12">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="topic" className="text-sm font-bold uppercase tracking-widest text-slate-400 ml-1">
              ভিডিওর টাইটেল বা বিষয় লিখুন (Video Topic)
            </label>
            <input
              id="topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="উদা: কিভাবে বিরিয়ানি রান্না করতে হয় / iPhone 16 Review"
              className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-6 py-4 text-xl focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all outline-none placeholder-slate-700"
              required
            />
          </div>

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <span className="text-sm font-bold uppercase tracking-widest text-slate-400">Response Language:</span>
              <div className="flex p-1 bg-slate-950 border border-slate-800 rounded-xl">
                <button
                  type="button"
                  onClick={() => setLanguage(Language.Bengali)}
                  className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                    language === Language.Bengali ? 'bg-orange-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  বাংলা (Bengali)
                </button>
                <button
                  type="button"
                  onClick={() => setLanguage(Language.English)}
                  className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${
                    language === Language.English ? 'bg-orange-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  English
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="px-10 py-4 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold rounded-2xl shadow-[0_0_20px_rgba(249,115,22,0.3)] hover:shadow-[0_0_30px_rgba(249,115,22,0.5)] transition-all disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-2"
            >
              {loading ? 'Tocxic is thinking...' : '🚀 ভাইরাল প্ল্যান তৈরি করো'}
            </button>
          </div>
        </form>
      </div>

      {loading && <Loader />}

      {error && (
        <div className="p-6 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-400 text-center animate-in fade-in zoom-in">
          <p className="font-bold mb-1">Oops! Something went wrong</p>
          <p className="text-sm opacity-80">{error}</p>
        </div>
      )}

      {strategy && !loading && (
        <StrategyDisplay strategy={strategy} />
      )}
    </Layout>
  );
};

export default App;

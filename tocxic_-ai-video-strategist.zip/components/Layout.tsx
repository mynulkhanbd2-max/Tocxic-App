
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center p-4 md:p-8">
      <header className="w-full max-w-4xl text-center mb-10">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight bg-gradient-to-r from-orange-500 via-red-500 to-purple-600 bg-clip-text text-transparent mb-4">
          🔥 Tocxic AI
        </h1>
        <p className="text-slate-400 text-lg md:text-xl font-medium">
          Expert Viral Video Strategist & Growth Hacker
        </p>
      </header>
      <main className="w-full max-w-4xl">
        {children}
      </main>
      <footer className="mt-20 py-8 text-slate-500 text-sm border-t border-slate-800 w-full text-center">
        Powered by Tocxic AI | Google Gemini 3 Flash
      </footer>
    </div>
  );
};

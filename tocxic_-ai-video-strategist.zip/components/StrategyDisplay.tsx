
import React from 'react';
import { ViralStrategy } from '../types';

interface StrategyDisplayProps {
  strategy: ViralStrategy;
}

const SectionTitle: React.FC<{ icon: string; title: string }> = ({ icon, title }) => (
  <h2 className="text-2xl font-bold flex items-center gap-3 mb-4 text-white border-b border-slate-800 pb-2">
    <span>{icon}</span> {title}
  </h2>
);

export const StrategyDisplay: React.FC<StrategyDisplayProps> = ({ strategy }) => {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Titles Section */}
      <section className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 backdrop-blur-sm">
        <SectionTitle icon="🎯" title="Refined Title Ideas" />
        <div className="grid gap-4">
          <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/50 hover:border-red-500/50 transition-colors group">
            <span className="text-xs font-bold text-red-400 uppercase tracking-wider mb-1 block">Clickbait but Honest</span>
            <p className="text-lg font-medium">{strategy.titles.clickbait}</p>
          </div>
          <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/50 hover:border-pink-500/50 transition-colors">
            <span className="text-xs font-bold text-pink-400 uppercase tracking-wider mb-1 block">Curiosity-driven</span>
            <p className="text-lg font-medium">{strategy.titles.curiosity}</p>
          </div>
          <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/50 hover:border-purple-500/50 transition-colors">
            <span className="text-xs font-bold text-purple-400 uppercase tracking-wider mb-1 block">Story-based</span>
            <p className="text-lg font-medium">{strategy.titles.story}</p>
          </div>
        </div>
      </section>

      {/* The Hook Section */}
      <section className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 backdrop-blur-sm">
        <SectionTitle icon="🪝" title="The Hook (First 5-10 Seconds)" />
        <div className="bg-red-500/10 border-l-4 border-red-500 p-6 rounded-r-xl italic text-lg leading-relaxed text-slate-200">
          "{strategy.hook}"
        </div>
      </section>

      {/* Script Outline */}
      <section className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 backdrop-blur-sm">
        <SectionTitle icon="📜" title="Script Outline" />
        <div className="space-y-6">
          {[
            { label: 'Intro', content: strategy.script.intro, color: 'text-blue-400' },
            { label: 'Body Point 1', content: strategy.script.body1, color: 'text-emerald-400' },
            { label: 'Body Point 2', content: strategy.script.body2, color: 'text-amber-400' },
            { label: 'Body Point 3', content: strategy.script.body3, color: 'text-orange-400' },
            { label: 'Conclusion', content: strategy.script.conclusion, color: 'text-slate-400' },
          ].map((item, idx) => (
            <div key={idx} className="relative pl-8 border-l-2 border-slate-800">
              <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-slate-800 border-2 border-slate-900"></div>
              <h3 className={`text-sm font-bold uppercase tracking-widest mb-1 ${item.color}`}>{item.label}</h3>
              <p className="text-slate-300 leading-relaxed">{item.content}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 backdrop-blur-sm">
        <SectionTitle icon="🗣️" title="Call to Action (CTA)" />
        <p className="text-xl font-semibold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          {strategy.cta}
        </p>
      </section>

      {/* Thumbnail Idea */}
      <section className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 backdrop-blur-sm">
        <SectionTitle icon="🖼️" title="Thumbnail Strategy" />
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-slate-800/40 p-5 rounded-xl border border-slate-700/50">
            <span className="text-xs font-bold text-slate-500 uppercase block mb-2 tracking-widest">Visual Concept</span>
            <p className="text-slate-200 leading-relaxed">{strategy.thumbnail.visualDescription}</p>
          </div>
          <div className="bg-slate-800/40 p-5 rounded-xl border border-slate-700/50 flex flex-col justify-center items-center text-center">
            <span className="text-xs font-bold text-slate-500 uppercase block mb-3 tracking-widest">Text Overlay Idea</span>
            <div className="bg-white text-black font-black px-4 py-2 text-2xl uppercase italic shadow-[4px_4px_0px_#ef4444]">
              {strategy.thumbnail.textOverlay}
            </div>
          </div>
        </div>
      </section>

      {/* SEO & Metadata */}
      <section className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 backdrop-blur-sm">
        <SectionTitle icon="🏷️" title="SEO & Metadata" />
        <div className="space-y-6">
          <div>
            <h4 className="text-sm font-bold text-slate-500 uppercase mb-2 tracking-widest">Optimized Description</h4>
            <p className="bg-slate-800/60 p-4 rounded-xl text-slate-300 border border-slate-700/50 italic">
              {strategy.seo.metaDescription}
            </p>
          </div>

          <div>
            <h4 className="text-sm font-bold text-slate-500 uppercase mb-2 tracking-widest">High-Volume Tags (15)</h4>
            <div className="flex flex-wrap gap-2">
              {strategy.seo.tags.map((tag, i) => (
                <span key={i} className="bg-slate-800 text-slate-300 px-3 py-1 rounded-full text-sm border border-slate-700">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-bold text-slate-500 uppercase mb-2 tracking-widest">Viral Hashtags</h4>
            <div className="flex flex-wrap gap-2">
              {strategy.seo.hashtags.map((tag, i) => (
                <span key={i} className="bg-red-500/20 text-red-400 px-3 py-1 rounded-md text-sm font-bold border border-red-500/30">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
        <button 
          onClick={() => copyToClipboard(`${strategy.seo.metaDescription}\n\nTags: ${strategy.seo.tags.join(', ')}\n\nHashtags: ${strategy.seo.hashtags.join(' ')}`)}
          className="mt-6 w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl transition-all border border-slate-700 flex items-center justify-center gap-2"
        >
          📋 Copy SEO Metadata
        </button>
      </section>
    </div>
  );
};


import React from 'react';

export const Loader: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center p-12 space-y-6">
      <div className="relative">
        <div className="w-16 h-16 border-4 border-slate-800 border-t-red-500 rounded-full animate-spin"></div>
        <div className="absolute top-0 left-0 w-16 h-16 border-4 border-transparent border-b-purple-500 rounded-full animate-pulse"></div>
      </div>
      <div className="text-center">
        <p className="text-xl font-semibold text-slate-300 animate-pulse">Analyzing Trends...</p>
        <p className="text-sm text-slate-500 mt-1">Crafting your viral content blueprint</p>
      </div>
    </div>
  );
};

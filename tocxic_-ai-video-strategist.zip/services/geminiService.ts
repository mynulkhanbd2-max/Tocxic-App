
import { GoogleGenAI, Type } from "@google/genai";
import { ViralStrategy, Language } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const strategySchema = {
  type: Type.OBJECT,
  properties: {
    titles: {
      type: Type.OBJECT,
      properties: {
        clickbait: { type: Type.STRING },
        curiosity: { type: Type.STRING },
        story: { type: Type.STRING }
      },
      required: ["clickbait", "curiosity", "story"]
    },
    hook: { type: Type.STRING },
    script: {
      type: Type.OBJECT,
      properties: {
        intro: { type: Type.STRING },
        body1: { type: Type.STRING },
        body2: { type: Type.STRING },
        body3: { type: Type.STRING },
        conclusion: { type: Type.STRING }
      },
      required: ["intro", "body1", "body2", "body3", "conclusion"]
    },
    cta: { type: Type.STRING },
    thumbnail: {
      type: Type.OBJECT,
      properties: {
        visualDescription: { type: Type.STRING },
        textOverlay: { type: Type.STRING }
      },
      required: ["visualDescription", "textOverlay"]
    },
    seo: {
      type: Type.OBJECT,
      properties: {
        metaDescription: { type: Type.STRING },
        tags: { type: Type.ARRAY, items: { type: Type.STRING } },
        hashtags: { type: Type.ARRAY, items: { type: Type.STRING } }
      },
      required: ["metaDescription", "tags", "hashtags"]
    }
  },
  required: ["titles", "hook", "script", "cta", "thumbnail", "seo"]
};

export async function generateViralStrategy(topic: string, language: Language): Promise<ViralStrategy> {
  const systemInstruction = `You are 'Tocxic', a world-class Video Content Strategist and Viral Marketing Specialist.
Your goal is to generate a complete viral growth package based on the user's topic.
Tone: Bold, Energetic, and Viral-focused. You don't just give advice; you give blueprints for dominance.
Target Language: ${language}.
Output must be structured JSON.`;

  const prompt = `Hey Tocxic, I need a viral strategy for this topic: "${topic}". 
Make it extreme and high-energy.
Generate:
1. 3 Catchy Title variations: Clickbait but honest, Curiosity-driven, Story-based.
2. A high-retention 10s hook that stops the scroll.
3. Detailed script outline (Intro, 3 Body points, Conclusion).
4. Creative and bold Call to Action (CTA).
5. Visual thumbnail description + powerful text overlay.
6. SEO Metadata: Click-optimized description (2 lines), 15 high-volume tags, 5 trending hashtags.
Everything must be in ${language}.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: strategySchema
      }
    });

    const text = response.text;
    if (!text) throw new Error("Empty response from AI");
    
    return JSON.parse(text) as ViralStrategy;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}
